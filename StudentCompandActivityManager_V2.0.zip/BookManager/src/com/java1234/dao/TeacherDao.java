package com.java1234.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.java1234.model.Teacher;
import com.java1234.util.StringUtil;

/**
 * �������Dao��
 * @author Administrator
 *
 */
public class TeacherDao {
	public int add(Connection con,Teacher Teacher )throws Exception{
		String sql="insert into teachers values(?,?,?,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, Teacher.getTNO());
		pstmt.setString(2, Teacher.getTNAME());		
		pstmt.setString(3, Teacher.getTCONTACT());
		pstmt.setString(4, Teacher.getTRESEARCH());
		pstmt.setString(5, Teacher.getTACCOMPLISHMENT());
		pstmt.setString(6, Teacher.getTAPPRAISE());
		pstmt.setString(7, Teacher.getTSEX());
		return pstmt.executeUpdate();
	}
	
	/**
	 * ��ѯͼ����𼯺�
	 * @param con
	 * @param bookType
	 * @return
	 * @throws Exception
	 */
	public ResultSet list(Connection con,Teacher Teacher) throws Exception{	
		StringBuffer sb=new StringBuffer("select * from teachers");
		if(StringUtil.isNotEmpty(Teacher.getTNAME())){
			sb.append(" and TNAME like '"+Teacher.getTNAME()+"'");
		}
		if(StringUtil.isNotEmpty(Teacher.getTSEX())){
			sb.append(" and TSEX like '%"+Teacher.getTSEX()+"%'");
		}
		if(StringUtil.isNotEmpty(Teacher.getTRESEARCH())){
			sb.append(" and TRESEARCH like '%"+Teacher.getTRESEARCH()+"%'");
		}
		PreparedStatement pstmt=con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		return pstmt.executeQuery();
	}
	
	/**
	 * ɾ��ͼ�����
	 * @param con
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public int delete(Connection con,String id)throws Exception{
		String sql="delete from teachers where TNO=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, id);
		return pstmt.executeUpdate();
	}
	
	/**
	 * ����ͼ�����
	 * @param con
	 * @param bookType
	 * @return
	 * @throws Exception
	 */
	public int update(Connection con,Teacher Teacher)throws Exception{
		String sql="update teachers set TNAME=?,TCONTACT=?,TRESEARCH=?,TACCOMPLISHMENT=?,TAPPRAISE=?,TSEX=? where TNO=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, Teacher.getTNAME());
		pstmt.setString(2, Teacher.getTCONTACT());
		pstmt.setString(3, Teacher.getTRESEARCH());
		pstmt.setString(4, Teacher.getTACCOMPLISHMENT());
		pstmt.setString(5, Teacher.getTAPPRAISE());
		pstmt.setString(6, Teacher.getTSEX());
		pstmt.setString(7, Teacher.getTNO());
		return pstmt.executeUpdate();
	}

}
