package com.java1234.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.java1234.model.Forum;
import com.java1234.util.StringUtil;
import com.java1234.view.ForumAdd;

/**
 * ͼ��Dao��
 * @author Administrator
 *
 */
public class ForumDao {

	/**
	 * ͼ������
	 * @param con
	 * @param book
	 * @return
	 * @throws Exception
	 */
	public int add(Connection con,Forum forum)throws Exception{
		String sql="insert into Forum values(?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		
		pstmt.setString(1, forum.getId());
		pstmt.setString(2, forum.getTitle());
		pstmt.setString(3, forum.getType());
		pstmt.setString(4, forum.getContent());

		return pstmt.executeUpdate();
	}
	
	/**
	 * ͼ����Ϣ��ѯ
	 * @param con
	 * @param forumAdd
	 * @return
	 * @throws Exception
	 */
	public ResultSet list(Connection con,Forum forumAdd)throws Exception{
		StringBuffer sb=new StringBuffer("select * from Forum");
		if(StringUtil.isNotEmpty(forumAdd.getTitle())){
			sb.append(" and title like '%"+forumAdd.getTitle()+"%'");
		}
		if(StringUtil.isNotEmpty(forumAdd.getType())){
			sb.append(" and type like '"+forumAdd.getType()+"'");
		}
		PreparedStatement pstmt=con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		return pstmt.executeQuery();
	}
	
	/**
	 * ͼ����Ϣɾ��
	 * @param con
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public int delete(Connection con,String id)throws Exception{
		String sql="delete from Forum where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, id);
		return pstmt.executeUpdate();
	}
	
	/**
	 * ͼ����Ϣ�޸�
	 * @param con
	 * @param forum
	 * @return
	 * @throws Exception
	 */
	public int update(Connection con,Forum forum)throws Exception{
		String sql="update Forum set title=?,type=?,content=? where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, forum.getTitle());
		pstmt.setString(2, forum.getType());
		pstmt.setString(3, forum.getContent());
		pstmt.setString(4, forum.getId());
		return pstmt.executeUpdate();
	}
	
	/**
	 * ָ��ͼ��������Ƿ����ͼ��
	 * @param con
	 * @param bookTypeId
	 * @return
	 * @throws Exception
	 */
	/*
	public boolean existBookByBookTypeId(Connection con,String bookTypeId)throws Exception{
		String sql="select * from t_book where bookTypeId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, bookTypeId);
		ResultSet rs=pstmt.executeQuery();
		return rs.next();
	}
	*/
}
