package com.java1234.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.java1234.model.activities;
import com.java1234.util.StringUtil;

/**
 * ͼ�����Dao��
 * @author Administrator
 *
 */
public class ActivitiesDao {

	/**
	 * ͼ���������
	 * @param con
	 * @param bookType
	 * @return
	 * @throws Exception
	 */
	public int add(Connection con,activities activities) throws Exception{
		String sql="insert into activities values(?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, activities.getAID());
		pstmt.setString(2, activities.getANAME());
		pstmt.setString(3, activities.getATYPE());
		pstmt.setString(4, activities.getAGRADE());
		pstmt.setString(5, activities.getAADDRESS());
		pstmt.setString(6, activities.getATIME());
		pstmt.setString(7, activities.getAAPPLICATION());
		pstmt.setString(8, activities.getAAWARD());
		return pstmt.executeUpdate();
	}
	/*
    private int AID;
	private String ANAME; // ����
	private String ATYPE; // ����
	private String AGRADE; // ����
	private String AADDRESS; // �����ص�
	private String ATIME; // ʱ��
	private String AAPPLICATION; // ��������
	private String AAWARD; // ��Ʒ
	*/
	/**
	 * ��ѯͼ����𼯺�
	 * @param con
	 * @param bookType
	 * @return
	 * @throws Exception
	 */
	public ResultSet list(Connection con,activities activities) throws Exception{	
		StringBuffer sb=new StringBuffer("select * from activities");
		if(StringUtil.isNotEmpty(activities.getANAME())){
			sb.append(" and ANAME like '%"+activities.getANAME()+"%'");
		}
		else if(StringUtil.isNotEmpty(activities.getATYPE())){
			sb.append(" and ATYPE like '%"+activities.getATYPE()+"%'");
		}
		else if(StringUtil.isNotEmpty(activities.getAGRADE())){
			sb.append(" and AGRADE like '%"+activities.getAGRADE()+"%'");
		}
		PreparedStatement pstmt=con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		return pstmt.executeQuery();
	}
	
	/**
	 * ɾ��ͼ�����
	 * @param con
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public int delete(Connection con,String AID)throws Exception{
		String sql="delete from activities where AID=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, AID);
		return pstmt.executeUpdate();
	}
	
	/**
	 * ����ͼ�����
	 * @param con
	 * @param bookType
	 * @return
	 * @throws Exception
	 */
	/*		pstmt.setString(1, activities.getANAME());
		pstmt.setString(2, activities.getATYPE());
		pstmt.setString(3, activities.getAGRADE());
		pstmt.setString(4, activities.getAADDRESS());
		pstmt.setString(5, activities.getATIME());
		pstmt.setString(6, activities.getAAPPLICATION());
		pstmt.setString(7, activities.getAAWARD());*/
	public int update(Connection con,activities activities)throws Exception{
		String sql="update activities set ANAME=?,ATYPE=?,AGRADE=?,AADDRESS=?,ATIME=?,AAPPLICATION=?,AAWARD=? where AID=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, activities.getANAME());
		pstmt.setString(2, activities.getATYPE());
		pstmt.setString(3, activities.getAGRADE());
		pstmt.setString(4, activities.getAADDRESS());
		pstmt.setString(5, activities.getATIME());
		pstmt.setString(6, activities.getAAPPLICATION());
		pstmt.setString(7, activities.getAAWARD());
		pstmt.setString(8, activities.getAID());
		return pstmt.executeUpdate();
	}
}
