package com.java1234.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.java1234.model.Competition;
import com.java1234.util.StringUtil;

/**
 * ����Dao��
 * @author Administrator
 *
 */
public class CompetitionTypeDao {

	/**
	 * ����
	 * @param con
	 * @param bookType
	 * @return
	 * @throws Exception
	 */
	public int add(Connection con,Competition Competition) throws Exception{
		String sql="insert into competition values(?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, Competition.getCID());
		pstmt.setString(2, Competition.getCNAME());
		pstmt.setString(3, Competition.getCTYPE());
		pstmt.setString(4, Competition.getCGRADE());
		pstmt.setString(5, Competition.getCAPPLICATION());
		pstmt.setString(6, Competition.getCTIME());
		pstmt.setString(7, Competition.getCDDL());
		pstmt.setString(8, Competition.getCREQUEST());
		pstmt.setString(9, Competition.getCAWARD());
		return pstmt.executeUpdate();
	}
	
	/**
	 * ��ѯ
	 * @param con
	 * @param bookType
	 * @return
	 * @throws Exception
	 */
	public static ResultSet list(Connection con,Competition Competition) throws Exception{	
		StringBuffer sb=new StringBuffer("select * from competition");
		if(StringUtil.isNotEmpty(Competition.getCNAME())){
			sb.append(" and CNAME like '%"+Competition.getCNAME()+"%'");
		}
		if(StringUtil.isNotEmpty(Competition.getCTYPE())){
			sb.append(" and CTYPE like '%"+Competition.getCTYPE()+"%'");
		}
		if(StringUtil.isNotEmpty(Competition.getCGRADE())){
			sb.append(" and CGRADE like '%"+Competition.getCGRADE()+"%'");
		}
		PreparedStatement pstmt=con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		return pstmt.executeQuery();
	}
	
	/**
	 * ɾ��
	 * @param con
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public static int delete(Connection con,String id)throws Exception{
		String sql="delete from competition where CID=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, id);
		return pstmt.executeUpdate();
	}
	
	/**
	 * ����
	 * @param con
	 * @param bookType
	 * @return
	 * @throws Exception
	 */
	public static int update(Connection con,Competition Competition)throws Exception{
		String sql="update competition set CNAME=?,CTYPE=?,CGRADE=?,CAPPLICATION=?,CTIME=?,CDDL=?,CREQUEST=?,CAWARD=? where CID=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, Competition.getCNAME());
		pstmt.setString(2, Competition.getCTYPE());
		pstmt.setString(3, Competition.getCGRADE());
		pstmt.setString(4, Competition.getCAPPLICATION());
		pstmt.setString(5, Competition.getCTIME());
		pstmt.setString(6, Competition.getCDDL());
		pstmt.setString(7, Competition.getCREQUEST());
		pstmt.setString(8, Competition.getCAWARD());
		pstmt.setString(9, Competition.getCID());
		return pstmt.executeUpdate();
	}
}
