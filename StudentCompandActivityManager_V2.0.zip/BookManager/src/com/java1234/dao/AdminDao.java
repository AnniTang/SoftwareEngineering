package com.java1234.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.java1234.model.Admin;
import com.java1234.model.User;

/**
 * �û�Dao��
 * @author Administrator
 *
 */
public class AdminDao {

	/**
	 * ��¼��֤
	 * @param con
	 * @param user
	 * @return
	 * @throws Exception
	 */
	public Admin login(Connection con,Admin admin) throws Exception{
		Admin resultUser=null;
		String sql="select * from adminuser where userName=? and password=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, admin.getUserName());
		pstmt.setString(2, admin.getPassword());

		ResultSet rs=pstmt.executeQuery();
		if(rs.next()){
			resultUser=new Admin();
			resultUser.setUserName(rs.getString("userName"));
			resultUser.setPassword(rs.getString("password"));

		}
		return resultUser;
	}
}
