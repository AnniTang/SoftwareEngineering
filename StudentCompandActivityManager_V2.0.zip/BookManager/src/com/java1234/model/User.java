package com.java1234.model;

/**
 * �û�ʵ��
 * @author Administrator
 *
 */
public class User {

	private int id; // ���
	private String userName; // �û���
	private String password; // ����
	private String shenfen; // ����
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
		this.shenfen = shenfen;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserName() {
		return userName; 
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getshenfen() {
		return shenfen;
	}
	public void setshenfen(String shenfen) {
		this.shenfen = shenfen;
	}
}
