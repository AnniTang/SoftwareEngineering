package com.java1234.model;

/**
 * ͼ��ʵ��
 * @author Administrator
 *
 */
public class Competition {
	private String CID;
	private String CNAME; // ���
	private String CTYPE; // ͼ������
	private String CGRADE; // ����
	private String CAPPLICATION; // �Ա�
	private String CTIME; // ͼ��۸�
	private String CDDL; // ��ע
	private String CREQUEST; // ͼ������Id
	private String CAWARD; // ͼ����������
	/*		pstmt.setString(1, Competition.getCName());
		pstmt.setString(2, Competition.getCTYPE());
		pstmt.setString(3, Competition.getCGRADE());
		pstmt.setString(4, Competition.getCAPPLICATION());
		pstmt.setString(5, Competition.getCTIME());
		pstmt.setString(6, Competition.getCDDL());
		pstmt.setString(7, Competition.getCREQUEST());
		pstmt.setString(8, Competition.getCAWARD());
		*/
	
	
	public Competition() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Competition(String CID,String CNAME, String CTYPE, String CTIME,String CGRADE,  String CREQUEST,String CAWARD) {
		super();
		this.CID=CID;
		this.CNAME = CNAME;
		this.CTYPE = CTYPE;
		this.CGRADE = CGRADE;
		this.CTIME = CTIME;
		this.CREQUEST = CREQUEST;
		this.CAWARD = CAWARD;
	}
	
	
	
	

	//Competition Competition=new Competition(id,cname,ctype,cgrade,cadd,cstart,cend,creq,caward);
	public Competition(String CID,String CNAME, String CTYPE,String CGRADE,String CAPPLICATION,String CTIME,String CDDL,String CREQUEST,String CAWARD) {
		super();
		this.CID=CID;
		this.CNAME = CNAME;
		this.CTYPE = CTYPE;
		this.CGRADE = CGRADE;
		this.CTIME = CTIME;
		this.CREQUEST = CREQUEST;
		this.CAWARD = CAWARD;
		this.CDDL = CDDL;
		this.CAPPLICATION = CAPPLICATION;
	}


	public Competition(String CNAME, String CTYPE, String CAWARD) {
		super();
		this.CNAME = CNAME;
		this.CTYPE = CTYPE;
		this.CAWARD = CAWARD;
	}

	public String getCID() {
		return CID;
	}
	public void setCID(String CID) {
		this.CID = CID;
	}
	public String getCNAME() {
		return CNAME;
	}
	public void setCNAME(String CNAME) {
		this.CNAME = CNAME;
	}
	public String getCTYPE() {
		return CTYPE;
	}
	public void setCTYPE(String CTYPE) {
		this.CTYPE = CTYPE;
	}
	public String getCGRADE() {
		return CGRADE;
	}
	public void setCGRADE(String CGRADE) {
		this.CGRADE = CGRADE;
	}
	public String getCAPPLICATION() {
		return CAPPLICATION;
	}
	public void setCAPPLICATION(String CAPPLICATION) {
		this.CAPPLICATION = CAPPLICATION;
	}
	public String getCTIME() {
		return CTIME;
	}
	public void setCTIME(String CTIME) {
		this.CTIME = CTIME;
	}
	public String getCDDL() {
		return CDDL;
	}
	public void setCDDL(String CDDL) {
		this.CDDL = CDDL;
	}
	public String getCREQUEST() {
		return CREQUEST;
	}
	public void setCREQUEST(String CREQUEST) {
		this.CREQUEST = CREQUEST;
	}
	public String getCAWARD() {
		return CAWARD;
	}
	public void setCAWARD(String CAWARD) {
		this.CAWARD = CAWARD;
	}
	
	
	
	
	
	
}
