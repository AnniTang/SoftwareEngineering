package com.java1234.model;

/**
 * ��ʦ
 * @author Administrator
 *
 */
public class Teacher {

	private String TNO; // ���
	private String TNAME; 
	private String TCONTACT; 
	private String TSEX; // �Ա�
	private String TRESEARCH ;
	private String TACCOMPLISHMENT; 
	private String TAPPRAISE; 
	
	
	
	public Teacher() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Teacher(String TNAME,String TCONTACT,String TRESEARCH,String TACCOMPLISHMENT,String TAPPRAISE, String TSEX) {
		super();
		this.TNAME = TNAME;
		this.TCONTACT = TCONTACT;
		this.TSEX = TSEX;
		this.TRESEARCH = TRESEARCH;
		this.TACCOMPLISHMENT = TACCOMPLISHMENT;
		this.TAPPRAISE = TAPPRAISE;
	}
	
	
	
	


	public Teacher(String TNO,String TNAME, String TCONTACT, String TRESEARCH,String  TACCOMPLISHMENT,String TAPPRAISE,String TSEX) {
		super();
		this.TNO=TNO;
		this.TNAME = TNAME;
		this.TCONTACT = TCONTACT;
		this.TSEX = TSEX;
		this.TRESEARCH = TRESEARCH;
		this.TACCOMPLISHMENT = TACCOMPLISHMENT;
		this.TAPPRAISE = TAPPRAISE;
	}


	public Teacher(String TNAME, String TSEX, String TRESEARCH) {
		super();
		this.TNAME = TNAME;
		this.TSEX = TSEX;
		this.TRESEARCH = TRESEARCH;
	}


	public String getTNO() {
		return TNO;
	}
	public void setTNO(String TNO) {
		this.TNO = TNO;
	}
	public String getTNAME() {
		return TNAME;
	}
	public void setTNAME(String TNAME) {
		this.TNAME = TNAME;
	}
	public String getTCONTACT() {
		return TCONTACT;
	}
	public void setTCONTACT(String TCONTACT) {
		this.TCONTACT = TCONTACT;
	}
	public String getTSEX() {
		return TSEX;
	}
	public void setTSEX(String TSEX) {
		this.TSEX = TSEX;
	}
	public String getTRESEARCH() {
		return TRESEARCH;
	}
	public void setTRESEARCH(String TRESEARCH) {
		this.TRESEARCH = TRESEARCH;
	}
	public String getTACCOMPLISHMENT() {
		return TACCOMPLISHMENT;
	}
	public void setTACCOMPLISHMENT(String TACCOMPLISHMENT) {
		this.TACCOMPLISHMENT = TACCOMPLISHMENT;
	}

	public String getTAPPRAISE() {
		return TAPPRAISE;
	}
	public void setTAPPRAISE(String TAPPRAISE) {
		this.TAPPRAISE = TAPPRAISE;
	}
	
	
	
	
	
	
}
