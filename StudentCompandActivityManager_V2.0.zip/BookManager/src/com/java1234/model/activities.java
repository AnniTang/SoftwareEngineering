package com.java1234.model;

/**
 * 
 * @author Administrator
 *
 */
public class activities {
	private String AID;
	private String ANAME; // ����
	private String ATYPE; // ����
	private String AGRADE; // ����
	private String AADDRESS; // �����ص�
	private String ATIME; // ʱ��
	private String AAPPLICATION; // ��������
	private String AAWARD; // ��Ʒ
	
	
	
	public activities() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public activities(String ANAME, String ATYPE, String AGRADE,  String AADDRESS, String ATIME,String AAPPLICATION,String AAWARD) {
		super();
		this.ANAME = ANAME;
		this.ATYPE = ATYPE;
		this.AGRADE = AGRADE;
		this.AADDRESS = AADDRESS;
		this.ATIME = ATIME;
		this.AAPPLICATION = AAPPLICATION;
		this.AAWARD = AAWARD;
	}
	//activities Competition=new activities(id,cname,ctype,cgrade,clocation,cstart,cadd,caward);
	
	public activities(String AID,String ANAME, String ATYPE, String AGRADE,  String AADDRESS, String ATIME,String AAPPLICATION,String AAWARD) {
		super();
		this.AID=AID;
		this.ANAME = ANAME;
		this.ATYPE = ATYPE;
		this.AGRADE = AGRADE;
		this.AADDRESS = AADDRESS;
		this.ATIME = ATIME;
		this.AAPPLICATION = AAPPLICATION;
		this.AAWARD = AAWARD;
	}	
	


	public activities(String ANAME, String ATYPE, String AGRADE) {
		super();
		this.ANAME = ANAME;
		this.ATYPE = ATYPE;
		this.AGRADE = AGRADE;
	}
	public String getAID() {
		return AID;
	}
	public void setAID(String AID) {
		this.AID = AID;
	}
	public String getANAME() {
		return ANAME;
	}
	public void setANAME(String ANAME) {
		this.ANAME = ANAME;
	}
	public String getATYPE() {
		return ATYPE;
	}
	public void setATYPE(String ATYPE) {
		this.ATYPE = ATYPE;
	}
	public String getAGRADE() {
		return AGRADE;
	}
	public void setAGRADE(String AGRADE) {
		this.AGRADE = AGRADE;
	}
	public String getAADDRESS() {
		return AADDRESS;
	}
	public void setSex(String AADDRESS) {
		this.AADDRESS = AADDRESS;
	}
	public String getATIME() {
		return ATIME;
	}
	public void setATIME(String ATIME) {
		this.ATIME = ATIME;
	}
	public String getAAPPLICATION() {
		return AAPPLICATION;
	}
	public void setAAPPLICATION(String AAPPLICATION) {
		this.AAPPLICATION = AAPPLICATION;
	}
	public String getAAWARD() {
		return AAWARD;
	}
	public void setBookTypeId(String AAWARD) {
		this.AAWARD = AAWARD;
	}
	
	
	
	
	
	
}
