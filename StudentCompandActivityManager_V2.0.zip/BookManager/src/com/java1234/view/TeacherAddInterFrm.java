package com.java1234.view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;

import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.LineBorder;

import com.java1234.dao.ForumDao;
import com.java1234.dao.BookTypeDao;
import com.java1234.dao.TeacherDao;
import com.java1234.model.Forum;
import com.java1234.model.BookType;
import com.java1234.model.Teacher;
import com.java1234.util.DbUtil;
import com.java1234.util.StringUtil;

public class TeacherAddInterFrm extends JInternalFrame {
	private JTextField TeacherNameTxt;
	private JTextField TeacheraccTxt;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTextField TeacheraddTxt;
	private JTextArea TeacherappTxt = new JTextArea();
	private JRadioButton manJrb =null;
	private JRadioButton femaleJrb =null;

	private DbUtil dbUtil = new DbUtil();
	private TeacherDao TeacherDao = new TeacherDao();
	private Teacher Teacher = new Teacher();
	private JTextField rescearchField;
	private JTextField TeacheridTxt;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TeacherAddInterFrm frame = new TeacherAddInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
	 * ��ʼ��ͼ�����������
	 */
	/*
	private void fillBookType() {
		Connection con = null;
		BookType bookType = null;
		try {
			con = dbUtil.getCon();
			ResultSet rs = bookTypeDao.list(con, new BookType());
			while (rs.next()) {
				bookType = new BookType();
				bookType.setId(rs.getInt("id"));
				bookType.setBookTypeName(rs.getString("bookTypeName"));
				this.bookTypeJcb.addItem(bookType);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	*/

	/**
	 * Create the frame.
	 */
	public TeacherAddInterFrm() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u6559\u5E08\u6DFB\u52A0");
		setBounds(100, 100, 603, 540);
		
		JLabel lblNewLabel = new JLabel("\u6559\u5E08\u59D3\u540D\uFF1A");
		
		TeacherNameTxt = new JTextField();
		TeacherNameTxt.setColumns(10);
		
		JLabel label = new JLabel("\u6559\u5E08\u6210\u5C31\uFF1A");
		
		TeacheraccTxt = new JTextField();
		TeacheraccTxt.setColumns(10);
		
		JLabel label_1 = new JLabel("\u6559\u5E08\u6027\u522B\uFF1A");
		
		manJrb = new JRadioButton("\u7537");
		manJrb.setSelected(true);
		buttonGroup.add(manJrb);
		
		femaleJrb = new JRadioButton("\u5973");
		buttonGroup.add(femaleJrb);
		
		JLabel label_2 = new JLabel("\u8054\u7CFB\u7535\u8BDD\uFF1A");
		
		TeacheraddTxt = new JTextField();
		TeacheraddTxt.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\u7814\u7A76\u7C7B\u522B\uFF1A");
		
		
		
		JLabel label_3 = new JLabel("\u6559\u5E08\u7B80\u4ECB\uFF1A");
		
		
		
		JButton btnNewButton = new JButton("\u6DFB\u52A0");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookAddActionPerformed(e);
			}
		});
		btnNewButton.setIcon(new ImageIcon(TeacherAddInterFrm.class.getResource("/images/add.png")));
		
		JButton btnNewButton_1 = new JButton("\u91CD\u7F6E");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetValueActionPerformed(e);
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(TeacherAddInterFrm.class.getResource("/images/reset.png")));
		
		rescearchField = new JTextField();
		rescearchField.setColumns(10);
		
		TeacheridTxt = new JTextField();
		TeacheridTxt.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("\u6559\u5E08\u7F16\u53F7\uFF1A");
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(48)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(label_3)
						.addComponent(lblNewLabel_1)
						.addComponent(label_1)
						.addComponent(lblNewLabel_2)
						.addComponent(lblNewLabel))
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(18)
							.addComponent(manJrb)
							.addGap(10)
							.addComponent(femaleJrb))
						.addGroup(groupLayout.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
								.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
									.addComponent(btnNewButton)
									.addPreferredGap(ComponentPlacement.RELATED, 183, Short.MAX_VALUE)
									.addComponent(btnNewButton_1))
								.addComponent(rescearchField, Alignment.LEADING)
								.addComponent(TeacherappTxt, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 318, Short.MAX_VALUE)
								.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
										.addComponent(TeacheridTxt)
										.addComponent(TeacherNameTxt, GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE))
									.addPreferredGap(ComponentPlacement.RELATED)
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
										.addGroup(groupLayout.createSequentialGroup()
											.addComponent(label)
											.addGap(18)
											.addComponent(TeacheraccTxt, GroupLayout.PREFERRED_SIZE, 141, GroupLayout.PREFERRED_SIZE))
										.addGroup(groupLayout.createSequentialGroup()
											.addComponent(label_2)
											.addGap(18)
											.addComponent(TeacheraddTxt)))))))
					.addContainerGap(136, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(45)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(TeacheraccTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(TeacheridTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_2))
					.addGap(38)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_2)
						.addComponent(TeacheraddTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel)
						.addComponent(TeacherNameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(43)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_1)
						.addComponent(manJrb)
						.addComponent(femaleJrb))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(rescearchField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_1))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(TeacherappTxt, GroupLayout.PREFERRED_SIZE, 167, GroupLayout.PREFERRED_SIZE)
							.addGap(45)
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(btnNewButton)
								.addComponent(btnNewButton_1)))
						.addComponent(label_3))
					.addGap(29))
		);
		getContentPane().setLayout(groupLayout);

		TeacherappTxt.setBorder(new LineBorder(new java.awt.Color(127,157,185), 1, false));
		//fillBookType();
	}
	
	private void resetValue(){
		this.TeacherNameTxt.setText("");
		this.TeacheraccTxt.setText("");
		this.manJrb.setSelected(true);
		this.TeacheraddTxt.setText("");
		/*
		if(this.bookTypeJcb.getItemCount()>0){
			this.bookTypeJcb.setSelectedIndex(0);			
		}*/
		this.TeacherappTxt.setText("");
		this.rescearchField.setText("");
	}
	
	/**
	 * ͼ�������¼�����
	 * @param evt
	 */
	private void bookAddActionPerformed(ActionEvent evt){
		String tName=TeacherNameTxt.getText();
		String tadd=TeacheraddTxt.getText();
		String tres=rescearchField.getText();
		String tacc=TeacheraccTxt.getText();
		String tapp=TeacherappTxt.getText();
		String tid=TeacheridTxt.getText();
		if(StringUtil.isEmpty(tName)){
			JOptionPane.showMessageDialog(null, "��ʦ��������Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(tadd)){
			JOptionPane.showMessageDialog(null, "��ʦ�ɾͲ���Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(tres)){
			JOptionPane.showMessageDialog(null, "��ʦ��ϵ��ʽ����Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(tacc)){
			JOptionPane.showMessageDialog(null, "��ʦ�о�������Ϊ�գ�");
			return;
		}		
		if(StringUtil.isEmpty(tapp)){
			JOptionPane.showMessageDialog(null, "��ʦ���۲���Ϊ�գ�");
			return;
		}
		String sex="";
		if(manJrb.isSelected()){
			sex="��";
		}else if(femaleJrb.isSelected()){
			sex="Ů";
		}
		/*
		BookType bookType=(BookType) bookTypeJcb.getSelectedItem();
		int bookTypeId=bookType.getId();
		*/
		Teacher Teacher=new Teacher(tid,tName,tadd,tres,tacc,tapp,sex);
		
		Connection con=null;
		try{
			con=dbUtil.getCon();
			int addNum=TeacherDao.add(con, Teacher);
			if(addNum==1){
				JOptionPane.showMessageDialog(null, "��ʦ���ӳɹ���");
				resetValue();
			}else{
				JOptionPane.showMessageDialog(null, "��ʦ����ʧ�ܣ�");
			}
		}catch(Exception e2){
			e2.printStackTrace();
			JOptionPane.showMessageDialog(null, "��ʦ����ʧ�ܣ�");
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
		}
	}
	
	/**
	 * �����¼�����
	 * @param evt
	 */
	private void resetValueActionPerformed(ActionEvent evt){
		this.resetValue();
	}
}
