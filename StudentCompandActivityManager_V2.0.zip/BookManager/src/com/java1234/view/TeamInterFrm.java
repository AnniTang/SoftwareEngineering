package com.java1234.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
import java.awt.Font;
import javax.swing.LayoutStyle.ComponentPlacement;

public class TeamInterFrm extends JInternalFrame {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TeamInterFrm frame = new TeamInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TeamInterFrm() {
		setFrameIcon(new ImageIcon(TeamInterFrm.class.getResource("/images/about.png")));
		getContentPane().setBackground(UIManager.getColor("Button.disabledShadow"));
		setClosable(true);
		setIconifiable(true);
		setTitle("\u8F6F\u4EF6\u5DE5\u7A0B\u5927\u4F5C\u4E1A\u56E2\u961F");
		setBounds(100, 100, 450, 300);
		
		JLabel lblNewLabel_1 = new JLabel("\u56E2\u961F\u6210\u5458\uFF1A\u91CD\u5E86\u90AE\u7535\u5927\u5B66\u8BA1\u7B97\u673A\u5B66\u9662\u6570\u636E\u79D1\u5B66\u4E0E\u5927\u6570\u636E\u6280\u672F\u4E13\u4E1A");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 15));
		
		JLabel lblNewLabel_2 = new JLabel("04081901\u73ED\uFF1A\u5468\u82AF\u5B87\u3001\u5510\u5B89\u59AE\u3001\u5F20\u8574\u6DB5\u3001\r\n\u674E\u6B22\u3001\u674E\u4E16\u51E4\u3001\u91D1\u6D9B");
		lblNewLabel_2.setFont(new Font("����", Font.PLAIN, 13));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
							.addGap(2)
							.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, 426, Short.MAX_VALUE))
						.addGroup(groupLayout.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 379, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(11)
					.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 81, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(82, Short.MAX_VALUE))
		);
		getContentPane().setLayout(groupLayout);

	}

}
