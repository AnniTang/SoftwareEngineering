package com.java1234.view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import com.java1234.dao.ActivitiesDao;
import com.java1234.model.activities;
import com.java1234.util.DbUtil;
import com.java1234.util.StringUtil;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;

public class ActManageInterFrm extends JInternalFrame {
	private JTextField ActNameTxt_1;
	private JTextArea ActTypeTxt = new JTextArea();
	private DbUtil dbUtil = new DbUtil();
	private ActivitiesDao ActivitiesDao = new ActivitiesDao();
	private JTextField idTxt;
	private JTextField ActNameTxt;
	private JTable CompTable;
	private JTextField ActTypeTxt_1;
	private JTextField ActGradeTxt;
	private JTextField ActgradeTxt;
	private JTextField ActApplicationTxt;
	private JTextField ActAddressTxt;
	private JTextField ActstartTxt;
	private JTextField ActawardTxt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ActManageInterFrm frame = new ActManageInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ActManageInterFrm() {
		setTitle("\u6D3B\u52A8\u4FE1\u606F\u4FEE\u6539");
		setClosable(true);
		setIconifiable(true);
		setBounds(100, 100, 1171, 700);
		
		JLabel lblNewLabel = new JLabel("\u6D3B\u52A8\u540D\u79F0\uFF1A");
		
		ActNameTxt_1 = new JTextField();
		ActNameTxt_1.setColumns(10);
		
		JButton btnNewButton = new JButton("\u67E5\u8BE2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookTypeSearchActionPerformed(e);
			}

			
		});
		btnNewButton.setIcon(new ImageIcon(ActManageInterFrm.class.getResource("/images/search.png")));
		
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "\u8868\u5355\u64CD\u4F5C", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setToolTipText("");
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon(ActManageInterFrm.class.getResource("/images/fengjing6_big.png")));
		
		JLabel lblNewLabel_5 = new JLabel("\u6D3B\u52A8\u79CD\u7C7B\uFF1A");
		
		JLabel lblNewLabel_6 = new JLabel("\u6D3B\u52A8\u7EA7\u522B\uFF1A");
		
		JScrollPane scrollPane = new JScrollPane();
		
		ActTypeTxt_1 = new JTextField();
		ActTypeTxt_1.setColumns(10);
		
		ActGradeTxt = new JTextField();
		ActGradeTxt.setColumns(10);
		
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(21)
					.addComponent(lblNewLabel_4, GroupLayout.PREFERRED_SIZE, 499, GroupLayout.PREFERRED_SIZE)
					.addGap(112)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 517, Short.MAX_VALUE)
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addComponent(lblNewLabel_6, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(lblNewLabel_5, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
							.addGap(65)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addComponent(ActGradeTxt)
								.addComponent(ActTypeTxt_1)
								.addComponent(ActNameTxt_1, GroupLayout.DEFAULT_SIZE, 139, Short.MAX_VALUE))
							.addGap(54)
							.addComponent(btnNewButton))
						.addComponent(panel, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 517, Short.MAX_VALUE))
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(66)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_4, GroupLayout.PREFERRED_SIZE, 333, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblNewLabel)
								.addComponent(ActNameTxt_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(btnNewButton))
							.addGap(18)
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblNewLabel_5)
								.addComponent(ActTypeTxt_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addGap(18)
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblNewLabel_6)
								.addComponent(ActGradeTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addGap(18)
							.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 237, GroupLayout.PREFERRED_SIZE)))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 216, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(25, Short.MAX_VALUE))
		);
		
		CompTable = new JTable();
		CompTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				bookTableMousePressed(e);
			}
		});
		CompTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u6BD4\u8D5B\u540D\u79F0", "\u6BD4\u8D5B\u7F16\u53F7", "\u6BD4\u8D5B\u7EA7\u522B", "\u62A5\u540D\u65B9\u5F0F", "\u5F00\u59CB\u65F6\u95F4", "\u7ED3\u675F\u65F6\u95F4", "\u53C2\u8D5B\u8981\u6C42", "\u6BD4\u8D5B\u5956\u52B1"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				true, true, true, true, true, true, true, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setColumnHeaderView(CompTable);
		
		JLabel lblNewLabel_1 = new JLabel("\u7F16\u53F7\uFF1A");
		
		idTxt = new JTextField();
		idTxt.setEditable(false);
		idTxt.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("\u6D3B\u52A8\u540D\u79F0\uFF1A");
		
		ActNameTxt = new JTextField();
		ActNameTxt.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("\u6D3B\u52A8\u79CD\u7C7B\uFF1A");
		
		
		
		JButton btnNewButton_1 = new JButton("\u4FEE\u6539");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookTypeUpdateActionPerformed(e);
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(ActManageInterFrm.class.getResource("/images/modify.png")));
		
		JButton btnNewButton_2 = new JButton("\u5220\u9664");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookTypeDeleteActionPerformed(e);
			}
		});
		btnNewButton_2.setIcon(new ImageIcon(ActManageInterFrm.class.getResource("/images/delete.png")));
		
		JLabel lblNewLabel_7 = new JLabel("\u6D3B\u52A8\u7EA7\u522B\uFF1A");
		
		ActgradeTxt = new JTextField();
		ActgradeTxt.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("\u62A5\u540D\u65B9\u5F0F\uFF1A");
		
		ActApplicationTxt = new JTextField();
		ActApplicationTxt.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("\u5F00\u59CB\u65F6\u95F4\uFF1A");
		
		JLabel lblNewLabel_10 = new JLabel("\u6D3B\u52A8\u5730\u70B9\uFF1A");
		
		ActAddressTxt = new JTextField();
		ActAddressTxt.setColumns(10);
		
		ActstartTxt = new JTextField();
		ActstartTxt.setColumns(10);
		
		ActawardTxt = new JTextField();
		ActawardTxt.setColumns(10);
		
		JLabel lblNewLabel_11 = new JLabel("\u6D3B\u52A8\u5956\u52B1\uFF1A");
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel_3)
								.addComponent(lblNewLabel_1)
								.addComponent(lblNewLabel_8, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_10))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
								.addComponent(ActAddressTxt)
								.addComponent(idTxt, GroupLayout.PREFERRED_SIZE, 66, GroupLayout.PREFERRED_SIZE)
								.addComponent(ActTypeTxt, GroupLayout.DEFAULT_SIZE, 77, Short.MAX_VALUE)
								.addComponent(ActApplicationTxt)))
						.addComponent(btnNewButton_1))
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(22)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel_11, GroupLayout.DEFAULT_SIZE, 109, Short.MAX_VALUE)
								.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
									.addComponent(lblNewLabel_2, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(lblNewLabel_7, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(lblNewLabel_9, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
							.addGap(80))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(107)
							.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
								.addComponent(btnNewButton_2)
								.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
									.addComponent(ActNameTxt, GroupLayout.DEFAULT_SIZE, 114, Short.MAX_VALUE)
									.addComponent(ActstartTxt)
									.addComponent(ActawardTxt)
									.addComponent(ActgradeTxt, Alignment.LEADING)))))
					.addGap(159))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
							.addComponent(lblNewLabel_1)
							.addComponent(idTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
							.addComponent(lblNewLabel_2)
							.addComponent(ActNameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_3)
						.addComponent(ActTypeTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_7)
						.addComponent(ActgradeTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_8)
						.addComponent(ActApplicationTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_9)
						.addComponent(ActstartTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_10)
						.addComponent(ActAddressTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_11)
						.addComponent(ActawardTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(20)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton_2)
						.addComponent(btnNewButton_1))
					.addContainerGap(7, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		getContentPane().setLayout(groupLayout);
		
		ActTypeTxt.setBorder(new LineBorder(new java.awt.Color(127,157,185), 1, false));
		
		this.fillTable(new activities());
	}
	
	/**
	 * ��ʼ����������
	 * @param bookType
	 */
	private void fillTable(activities activities) {
		DefaultTableModel dtm = (DefaultTableModel) CompTable.getModel();
		dtm.setRowCount(0);
		Connection con = null;
		try {
			con = dbUtil.getCon();
			ResultSet rs = ActivitiesDao.list(con, activities);
			while (rs.next()) {
				Vector v = new Vector();
				v.add(rs.getString("AID"));
				v.add(rs.getString("ANAME"));
				v.add(rs.getString("ATYPE"));
				v.add(rs.getString("AGRADE"));
				v.add(rs.getString("AADDRESS"));
				v.add(rs.getString("ATIME"));
				v.add(rs.getString("AAPPLICATION"));
				v.add(rs.getString("AAWARD"));
				
				dtm.addRow(v);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	/**
	 *�޸��¼�����
	 * @param evt
	 */
	private void bookTypeUpdateActionPerformed(ActionEvent evt){
		String id = idTxt.getText();

		if (StringUtil.isEmpty(id)) {
			JOptionPane.showMessageDialog(null, "��ѡ��Ҫ�޸ĵļ�¼��");
			return;
		}
		String aname=ActNameTxt.getText();
		String atype=ActTypeTxt.getText();
		String aadd=ActApplicationTxt.getText();
		String astart=ActstartTxt.getText();
		String alocation=ActAddressTxt.getText();
		String agrade=ActgradeTxt.getText();
		String aaward=ActawardTxt.getText();
		if(StringUtil.isEmpty(aname)){
			JOptionPane.showMessageDialog(null, "����Ʋ���Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(atype)){
			JOptionPane.showMessageDialog(null, "����Ͳ���Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(aadd)){
			JOptionPane.showMessageDialog(null, "��ص㲻��Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(astart)){
			JOptionPane.showMessageDialog(null, "���ʼʱ�䲻��Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(agrade)){
			JOptionPane.showMessageDialog(null, "�������Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(aaward)){
			JOptionPane.showMessageDialog(null, "���������Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(alocation)){
			JOptionPane.showMessageDialog(null, "�������ʽ����Ϊ�գ�");
			return;
		}
		activities activities=new activities(id,aname,atype,agrade,alocation,astart,aadd,aaward);
		Connection con = null;
		try {
			con = dbUtil.getCon();
			int modifyNum = ActivitiesDao.update(con, activities);
			if (modifyNum == 1) {
				JOptionPane.showMessageDialog(null, "�޸ĳɹ�");
				resetValue();
				fillTable(new activities());
			} else {
				JOptionPane.showMessageDialog(null, "�޸�ʧ��");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "�޸�ʧ��");
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * ͼ�����ɾ���¼�����
	 * @param evt
	 */
	private void bookTypeDeleteActionPerformed(ActionEvent evt){
		String id = this.idTxt.getText();
		if (StringUtil.isEmpty(id)) {
			JOptionPane.showMessageDialog(null, "��ѡ��Ҫɾ���ļ�¼��");
			return;
		}
		int n = JOptionPane.showConfirmDialog(null, "ȷ��Ҫɾ��������¼��");
		if (n == 0) {
			Connection con = null;
			try {
				con = dbUtil.getCon();
				int deleteNum = ActivitiesDao.delete(con, id);
				if (deleteNum == 1) {
					JOptionPane.showMessageDialog(null, "ɾ���ɹ�");
					resetValue();
					fillTable(new activities());
				} else {
					JOptionPane.showMessageDialog(null, "ɾ��ʧ��");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "ɾ��ʧ��");
			} finally {
				try {
					dbUtil.closeCon(con);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	/**
	 * �����е���¼�����
	 * @param evt
	 */
	private void bookTableMousePressed(MouseEvent evt) {
		// ��ȡѡ�е���
		int row = this.CompTable.getSelectedRow();
		this.idTxt.setText((String) CompTable.getValueAt(row, 0));
		this.ActNameTxt.setText((String) CompTable.getValueAt(row, 1));
		this.ActTypeTxt.setText((String) CompTable.getValueAt(row, 2));
		this.ActgradeTxt.setText((String) CompTable.getValueAt(row, 3));
		this.ActAddressTxt.setText((String) CompTable.getValueAt(row, 4));
		this.ActstartTxt.setText((String) CompTable.getValueAt(row, 5));
		this.ActApplicationTxt.setText((String) CompTable.getValueAt(row, 6));
		this.ActawardTxt.setText((String) CompTable.getValueAt(row, 7));
	}
	private void bookTypeSearchActionPerformed(ActionEvent e) {
		String ANAME = this.ActNameTxt_1.getText();
		String ATYPE = this.ActTypeTxt_1.getText();
		String AGRADE = this.ActGradeTxt.getText();
		activities activities = new activities();
		activities.setANAME(ANAME);
		activities.setATYPE(ATYPE);
		activities.setAGRADE(AGRADE);
		this.fillTable(activities);
	}
	
	/**
	 * ��������
	 */
	private void resetValue() {
		this.idTxt.setText("");
		this.ActNameTxt.setText("");
		this.ActTypeTxt.setText("");
		this.ActgradeTxt.setText("");
		this.ActawardTxt.setText("");
		this.ActstartTxt.setText("");
		this.ActApplicationTxt.setText("");
		this.ActAddressTxt.setText("");
	}
}
