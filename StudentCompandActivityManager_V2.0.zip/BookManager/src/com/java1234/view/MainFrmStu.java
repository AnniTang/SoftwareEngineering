package com.java1234.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Toolkit;

public class MainFrmStu extends JFrame {

	private JPanel contentPane;
	private JDesktopPane table =null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrmStu frame = new MainFrmStu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrmStu() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainFrmStu.class.getResource("/images/学生.png")));
		setTitle("大学生科研文创活动信息交流平台（学生端）主界面");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("\u57FA\u672C\u6570\u636E\u7EF4\u62A4");
		mnNewMenu.setIcon(new ImageIcon(MainFrmStu.class.getResource("/images/base.png")));
		menuBar.add(mnNewMenu);
		
		JMenu mnNewMenu_1 = new JMenu("活动管理");
		mnNewMenu_1.setIcon(new ImageIcon(MainFrmStu.class.getResource("/images/bookTypeManager.png")));
		mnNewMenu.add(mnNewMenu_1);
		
		JMenuItem menuItem = new JMenuItem("活动添加");
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ActTypeAddInterFrm actTypeAddInterFrm=new ActTypeAddInterFrm();
				actTypeAddInterFrm.setVisible(true);
				table.add(actTypeAddInterFrm);
			}
		});
		menuItem.setIcon(new ImageIcon(MainFrmStu.class.getResource("/images/add.png")));
		mnNewMenu_1.add(menuItem);
		
		JMenuItem menuItem_1 = new JMenuItem("活动维护");
		menuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ActManageInterFrm ActManageInterFrm=new ActManageInterFrm();
				ActManageInterFrm.setVisible(true);
				table.add(ActManageInterFrm);
			}
		});
		menuItem_1.setIcon(new ImageIcon(MainFrmStu.class.getResource("/images/edit.png")));
		mnNewMenu_1.add(menuItem_1);
		
		JMenu mnNewMenu_2 = new JMenu("比赛管理");
		mnNewMenu_2.setIcon(new ImageIcon(MainFrmStu.class.getResource("/images/bookManager.png")));
		mnNewMenu.add(mnNewMenu_2);
		
		JMenuItem menuItem_2 = new JMenuItem("比赛添加");
		menuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CompAddInterFrm CompAddInterFrm=new CompAddInterFrm();
				CompAddInterFrm.setVisible(true);
				table.add(CompAddInterFrm);
			}
		});


		menuItem_2.setIcon(new ImageIcon(MainFrmStu.class.getResource("/images/add.png")));
		mnNewMenu_2.add(menuItem_2);
		
		JMenuItem mntmBs = new JMenuItem("比赛维护");
		mntmBs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CompManageInterFrm compManageInterFrm=new CompManageInterFrm();
				compManageInterFrm.setVisible(true);
				table.add(compManageInterFrm);
			}
		});
		mntmBs.setIcon(new ImageIcon(MainFrmStu.class.getResource("/images/edit.png")));
		mnNewMenu_2.add(mntmBs);
		
		JMenuItem menuItem_4 = new JMenuItem("\u5B89\u5168\u9000\u51FA");
		menuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result=JOptionPane.showConfirmDialog(null, "退出？");
				if(result==0){
					dispose();
				}
			}
		});
		
		JMenu mnNewMenu_3 = new JMenu("交流论坛");
		mnNewMenu_3.setIcon(new ImageIcon(MainFrmStu.class.getResource("/images/userName.png")));
		mnNewMenu.add(mnNewMenu_3);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("发帖子");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ForumAdd ForumAdd=new ForumAdd();
				ForumAdd.setVisible(true);
				table.add(ForumAdd);
			}
		});
		mntmNewMenuItem.setIcon(new ImageIcon(MainFrmStu.class.getResource("/images/modify.png")));
		mnNewMenu_3.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("看帖子");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ForumViewInterFrm ForumViewInterFrm=new ForumViewInterFrm();
				ForumViewInterFrm.setVisible(true);
				table.add(ForumViewInterFrm);
			}
		});
		mntmNewMenuItem_1.setIcon(new ImageIcon(MainFrmStu.class.getResource("/images/介绍.png")));
		mnNewMenu_3.add(mntmNewMenuItem_1);
		menuItem_4.setIcon(new ImageIcon(MainFrmStu.class.getResource("/images/exit.png")));
		mnNewMenu.add(menuItem_4);
		
		JMenu menu = new JMenu("\u5173\u4E8E\u6211\u4EEC");
		menu.setIcon(new ImageIcon(MainFrmStu.class.getResource("/images/about.png")));
		menuBar.add(menu);
		
		JMenuItem mntmjava = new JMenuItem("软件工程大作业团队");
		mntmjava.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TeamInterFrm TeamInterFrm=new TeamInterFrm();
				TeamInterFrm.setVisible(true);
				table.add(TeamInterFrm);
			}
		});
		mntmjava.setIcon(new ImageIcon(MainFrmStu.class.getResource("/images/about.png")));
		menu.add(mntmjava);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		table = new JDesktopPane();
		contentPane.add(table, BorderLayout.CENTER);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(MainFrmStu.class.getResource("/images/motto.png")));
		lblNewLabel.setBounds(10, 0, 325, 76);
		table.add(lblNewLabel);
		
		
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
	}
}
