package com.java1234.view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import com.java1234.dao.CompetitionTypeDao;
import com.java1234.model.Competition;
import com.java1234.util.DbUtil;
import com.java1234.util.StringUtil;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;

public class CompAddInterFrm extends JInternalFrame {
	
	private DbUtil dbUtil=new DbUtil();
	private CompetitionTypeDao CompetitionTypeDao=new CompetitionTypeDao();
	private Competition Competition=new Competition();
	private JTextField CompNameTxt;
	private JTextArea CompbaomingTxt = new JTextArea();
	private JTextField Compstarttxt;
	private JTextField Compendtxt;
	
	private JComboBox Comptypejcb;
	private JComboBox Compclassjcb;
	private JTextField CompreqTxt;
	private JTextField CompawardTxt;
	private JTextField CompTypeTxt;
	private JTextField CompGradeTxt;
	private JTextField CompIDTxt;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CompAddInterFrm frame = new CompAddInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	private void fillAType() {
		Connection con = null;
		Competition Competition = null;
		try {
			con = dbUtil.getCon();
			ResultSet rs = CompetitionTypeDao.list(con, new Competition());
			while (rs.next()) {
				Competition = new Competition();
				//activities.set(rs.getInt("id"));
				Competition.setCTYPE(rs.getString("CTYPE"));
				//this.Comptypejcb.addItem(Competition);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	/**
	 * Create the frame.
	 */
	public CompAddInterFrm() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u6BD4\u8D5B\u6DFB\u52A0");
		setBounds(100, 100, 587, 433);
		
		JLabel lblNewLabel = new JLabel("\u6BD4\u8D5B\u540D\u79F0\uFF1A");
		
		CompNameTxt = new JTextField();
		CompNameTxt.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\u6BD4\u8D5B\u62A5\u540D\u65B9\u5F0F\uFF1A");
		
		JButton btnNewButton = new JButton("\u6DFB\u52A0");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ActivitiesAddActionPerformed(e);
			}
		});
		btnNewButton.setIcon(new ImageIcon(CompAddInterFrm.class.getResource("/images/add.png")));
		
		JButton btnNewButton_1 = new JButton("\u91CD\u7F6E");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetValueActionPerformed(e);
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(CompAddInterFrm.class.getResource("/images/reset.png")));
		
		JLabel lblNewLabel_2 = new JLabel("\u6BD4\u8D5B\u7C7B\u522B\uFF1A");
		
		JLabel lblNewLabel_3 = new JLabel("\u6BD4\u8D5B\u7EA7\u522B\uFF1A");
		
		JLabel lblNewLabel_4 = new JLabel("\u6BD4\u8D5B\u5F00\u59CB\u65F6\u95F4\uFF1A");
		
		JLabel lblNewLabel_7 = new JLabel("\u6BD4\u8D5B\u7ED3\u675F\u65F6\u95F4\uFF1A");
		
		Compstarttxt = new JTextField();
		Compstarttxt.setColumns(10);
		
		Compendtxt = new JTextField();
		Compendtxt.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("\u53C2\u8D5B\u8981\u6C42\uFF1A");
		
		CompreqTxt = new JTextField();
		CompreqTxt.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("\u6BD4\u8D5B\u5956\u52B1\uFF1A");
		
		CompawardTxt = new JTextField();
		CompawardTxt.setColumns(10);
		
		CompTypeTxt = new JTextField();
		CompTypeTxt.setColumns(10);
		
		CompGradeTxt = new JTextField();
		CompGradeTxt.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("\u6BD4\u8D5B\u7F16\u53F7\uFF1A");
		
		CompIDTxt = new JTextField();
		CompIDTxt.setColumns(10);
		
		
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(90)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel_8, GroupLayout.PREFERRED_SIZE, 68, GroupLayout.PREFERRED_SIZE)
							.addContainerGap())
						.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
							.addGroup(groupLayout.createSequentialGroup()
								.addComponent(lblNewLabel_5)
								.addContainerGap())
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(lblNewLabel_7)
									.addContainerGap())
								.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
									.addGroup(groupLayout.createSequentialGroup()
										.addComponent(lblNewLabel_4, GroupLayout.DEFAULT_SIZE, 475, Short.MAX_VALUE)
										.addContainerGap())
									.addGroup(groupLayout.createSequentialGroup()
										.addComponent(lblNewLabel_9, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
										.addContainerGap())
									.addGroup(groupLayout.createSequentialGroup()
										.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
											.addComponent(lblNewLabel)
											.addComponent(lblNewLabel_2, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE)
											.addComponent(lblNewLabel_1, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE)
											.addComponent(lblNewLabel_3, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE))
										.addPreferredGap(ComponentPlacement.RELATED)
										.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
											.addComponent(CompGradeTxt, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
											.addComponent(CompTypeTxt, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
											.addComponent(CompbaomingTxt, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
											.addGroup(groupLayout.createSequentialGroup()
												.addComponent(btnNewButton)
												.addPreferredGap(ComponentPlacement.RELATED, 139, Short.MAX_VALUE)
												.addComponent(btnNewButton_1))
											.addComponent(CompNameTxt, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
											.addComponent(CompIDTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
											.addComponent(Compstarttxt, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
											.addComponent(Compendtxt, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
											.addComponent(CompreqTxt, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
											.addComponent(CompawardTxt, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE))
										.addGap(64)))))))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(25)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_9)
						.addComponent(CompIDTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(CompNameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(CompTypeTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(18)
							.addComponent(lblNewLabel_3))
						.addGroup(groupLayout.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(CompGradeTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(7)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(CompbaomingTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_4)
						.addComponent(Compstarttxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_7)
						.addComponent(Compendtxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_5)
						.addComponent(CompreqTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_8)
						.addComponent(CompawardTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton_1)
						.addComponent(btnNewButton))
					.addGap(20))
		);
		getContentPane().setLayout(groupLayout);
		
		CompbaomingTxt.setBorder(new LineBorder(new java.awt.Color(127,157,185), 1, false));
		fillAType();
	}
	
	/**
	 * ͼ����������¼�����
	 * @param evt
	 */
	private void ActivitiesAddActionPerformed(ActionEvent evt){
		String CName=CompNameTxt.getText();
		String Cbm=CompbaomingTxt.getText();
		String Creq=CompreqTxt.getText();
		String Cstart=Compstarttxt.getText();
		String Cend=Compendtxt.getText();
		String Ctype=CompTypeTxt.getText();
		String Cgrade=CompGradeTxt.getText();
		String Cid=CompIDTxt.getText();
		String Caw=CompawardTxt.getText();
		/*
		if(this.Comptypejcb.getItemCount()>0){
			this.Comptypejcb.setSelectedIndex(0);			
		}
		if(this.Compclassjcb.getItemCount()>0){
			this.Compclassjcb.setSelectedIndex(0);			
		}
		*/
		/*
		 * 
		 * 	private JTextField actNameTxt;
	private JTextArea actbaomingTxt = new JTextArea();
	private JTextField actlocationtxt;
	private JTextField acttimetxt;
	private JTextField actawardtxt;*/
		 
		if(StringUtil.isEmpty(CName)){
			JOptionPane.showMessageDialog(null, "�������Ʋ���Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(Cbm)){
			JOptionPane.showMessageDialog(null, "������ʽ����Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(Creq)){
			JOptionPane.showMessageDialog(null, "�����ص㲻��Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(Cstart)){
			JOptionPane.showMessageDialog(null, "��ʼʱ�䲻��Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(Caw)){
			JOptionPane.showMessageDialog(null, "������������Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(Ctype)){
			JOptionPane.showMessageDialog(null, "���������Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(Cgrade)){
			JOptionPane.showMessageDialog(null, "����������Ϊ�գ�");
			return;
		}
		/*
		activities activities=(activities) Comptypejcb.getSelectedItem();
		String atype=activities.getATYPE();
		activities activitie=(activities) Compclassjcb.getSelectedItem();
		String agrade=activitie.getAGRADE();
		*/
		//	public Competition(String CID,String CNAME, String CTYPE,String CGRADE,String CAPPLICATION,String CTIME,String CDDL,String CREQUEST,String CAWARD)
		Competition Competition=new Competition(Cid,CName,Ctype,Cgrade,Cbm,Cstart,Cend,Creq,Caw);
		Connection con=null;
		try {
			con=dbUtil.getCon();
			int n=CompetitionTypeDao.add(con, Competition);
			if(n==1){
				JOptionPane.showMessageDialog(null, "�������ӳɹ���");
				resetValues();
			}else{
				JOptionPane.showMessageDialog(null, "��������ʧ�ܣ�");
			}
		} catch (Exception e2) {
			e2.printStackTrace(); 
			JOptionPane.showMessageDialog(null, "��������ʧ�ܣ�");
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * �����¼�����
	 * @param evt
	 */
	private void resetValueActionPerformed(ActionEvent evt){
		this.resetValues();
	}
	
	private void resetValues(){
		this.CompNameTxt.setText("");
		this.CompbaomingTxt.setText("");
		this.Compendtxt.setText("");
		this.Compstarttxt.setText("");
		this.CompreqTxt.setText("");
		this.CompawardTxt.setText("");
		this.CompTypeTxt.setText("");
		this.CompGradeTxt.setText("");
	}
}
