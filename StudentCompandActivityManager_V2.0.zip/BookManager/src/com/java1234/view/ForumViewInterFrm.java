package com.java1234.view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import com.java1234.dao.ForumDao;
import com.java1234.model.Forum;
import com.java1234.util.DbUtil;
import com.java1234.util.StringUtil;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;

public class ForumViewInterFrm extends JInternalFrame {
	private JTextField TieTitleTxt_1;
	private DbUtil dbUtil = new DbUtil();
	private ForumDao ForumDao = new ForumDao();
	private JTable CompTable;
	private JRadioButton exprbt=null;
	private JRadioButton comprbt=null;
	private JRadioButton exprbt_1=null;
	private JRadioButton comprbt_1=null;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ForumViewInterFrm frame = new ForumViewInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ForumViewInterFrm() {
		setTitle("\u770B\u5E16\u5B50");
		setClosable(true);
		setIconifiable(true);
		setBounds(100, 100, 1171, 700);
		
		JLabel lblNewLabel = new JLabel("\u5E16\u5B50\u6807\u9898\uFF1A");
		
		TieTitleTxt_1 = new JTextField();
		TieTitleTxt_1.setColumns(10);
		
		JButton btnNewButton = new JButton("\u67E5\u8BE2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookTypeSearchActionPerformed(e);
			}

			
		});
		btnNewButton.setIcon(new ImageIcon(ForumViewInterFrm.class.getResource("/images/search.png")));
		
		JLabel lblNewLabel_5 = new JLabel("\u5E16\u5B50\u79CD\u7C7B\uFF1A");
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		
		exprbt = new JRadioButton("\u7ECF\u9A8C\u4EA4\u6D41");
		buttonGroup.add(exprbt);
		
		comprbt = new JRadioButton("\u6BD4\u8D5B\u7EC4\u961F");
		buttonGroup.add(comprbt);
		
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(67)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addComponent(lblNewLabel_5, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
							.addGap(65)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(TieTitleTxt_1, GroupLayout.PREFERRED_SIZE, 139, GroupLayout.PREFERRED_SIZE)
									.addGap(54)
									.addComponent(btnNewButton))
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(exprbt, GroupLayout.PREFERRED_SIZE, 127, GroupLayout.PREFERRED_SIZE)
									.addGap(18)
									.addComponent(comprbt, GroupLayout.PREFERRED_SIZE, 127, GroupLayout.PREFERRED_SIZE))))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(54)
							.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 1082, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(23, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(66)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(TieTitleTxt_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_5)
						.addComponent(exprbt)
						.addComponent(comprbt))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 396, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(141, Short.MAX_VALUE))
		);
		
		CompTable = new JTable();
		CompTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				//bookTableMousePressed(e);
			}
		});
		CompTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u6BD4\u8D5B\u540D\u79F0", "\u6BD4\u8D5B\u7F16\u53F7", "\u6BD4\u8D5B\u7EA7\u522B", "\u62A5\u540D\u65B9\u5F0F", "\u5F00\u59CB\u65F6\u95F4", "\u7ED3\u675F\u65F6\u95F4", "\u53C2\u8D5B\u8981\u6C42", "\u6BD4\u8D5B\u5956\u52B1"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				true, true, true, true, true, true, true, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setColumnHeaderView(CompTable);
		getContentPane().setLayout(groupLayout);
		
		this.fillTable(new Forum());
	}
	
	/**
	 * ��ʼ����������
	 * @param bookType
	 */
	private void fillTable(Forum Forum) {
		DefaultTableModel dtm = (DefaultTableModel) CompTable.getModel();
		dtm.setRowCount(0);
		Connection con = null;
		try {
			con = dbUtil.getCon();
			ResultSet rs = ForumDao.list(con, Forum);
			while (rs.next()) {
				Vector v = new Vector();
				v.add(rs.getString("id"));
				v.add(rs.getString("title"));
				v.add(rs.getString("type"));
				v.add(rs.getString("content"));			
				dtm.addRow(v);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	/**
	 * �����е���¼�����
	 * @param evt
	 */
	/*
	private void bookTableMousePressed(MouseEvent evt) {
		// ��ȡѡ�е���
		int row = this.CompTable.getSelectedRow();
		this.idTxt.setText((String) CompTable.getValueAt(row, 0));
		this.TieTitleTxt.setText((String) CompTable.getValueAt(row, 1));
		String type = (String) CompTable.getValueAt(row, 2);
		if ("���齻��".equals(type)) {
			this.exprbt_1.setSelected(true);
		} else if ("�������".equals(type)) {
			this.comprbt_1.setSelected(true);
		}
		this.TieContentTxt.setText((String) CompTable.getValueAt(row, 3));
	}
	*/
	private void bookTypeSearchActionPerformed(ActionEvent e) {
		String ANAME = this.TieTitleTxt_1.getText();
		//String ATYPE = this.TieContentTxt.getText();
		String atype="";
		if(exprbt.isSelected()){
			atype="���齻��";
		}else if(comprbt.isSelected()){
			atype="�������";
		}
		Forum Forum = new Forum();
		Forum.setTitle(ANAME);
		Forum.setType(atype);
		this.fillTable(Forum);
	}
	
	/**
	 * ��������
	 */
	/*
	private void resetValue() {
		this.idTxt.setText("");
		this.TieTitleTxt.setText("");
		this.exprbt_1.setSelected(true);
		this.TieContentTxt.setText("");
	}
	*/
}
