package com.java1234.view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import com.java1234.dao.ActivitiesDao;
import com.java1234.dao.BookTypeDao;
import com.java1234.model.activities;
import com.java1234.util.DbUtil;
import com.java1234.util.StringUtil;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;

public class ActTypeAddInterFrm extends JInternalFrame {
	
	private DbUtil dbUtil=new DbUtil();
	private ActivitiesDao ActivitiesDao=new ActivitiesDao();
	private activities activities=new activities();
	private JTextField actNameTxt;
	private JTextArea actbaomingTxt = new JTextArea();
	private JTextField actlocationtxt;
	private JTextField acttimetxt;
	private JTextField actawardtxt;
	private JComboBox acttypejcb;
	private JComboBox actclassjcb;
	private JTextField ActIDTxt;
	private JTextField ActtypeTxt;
	private JTextField ActGradeTxt;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ActTypeAddInterFrm frame = new ActTypeAddInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	private void fillAType() {
		Connection con = null;
		activities activities = null;
		try {
			con = dbUtil.getCon();
			ResultSet rs = ActivitiesDao.list(con, new activities());
			while (rs.next()) {
				activities = new activities();
				//activities.set(rs.getInt("id"));
				activities.setATYPE(rs.getString("ATYPE"));
				//this.acttypejcb.addItem(activities);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	/**
	 * Create the frame.
	 */
	public ActTypeAddInterFrm() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u6D3B\u52A8\u6DFB\u52A0");
		setBounds(100, 100, 587, 407);
		
		JLabel lblNewLabel = new JLabel("\u6D3B\u52A8\u540D\u79F0\uFF1A");
		
		actNameTxt = new JTextField();
		actNameTxt.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\u6D3B\u52A8\u62A5\u540D\u65B9\u5F0F\uFF1A");
		
		JButton btnNewButton = new JButton("\u6DFB\u52A0");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ActivitiesAddActionPerformed(e);
			}
		});
		btnNewButton.setIcon(new ImageIcon(ActTypeAddInterFrm.class.getResource("/images/add.png")));
		
		JButton btnNewButton_1 = new JButton("\u91CD\u7F6E");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetValueActionPerformed(e);
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(ActTypeAddInterFrm.class.getResource("/images/reset.png")));
		
		JLabel lblNewLabel_2 = new JLabel("\u6D3B\u52A8\u7C7B\u522B\uFF1A");
		
		JLabel lblNewLabel_3 = new JLabel("\u6D3B\u52A8\u7EA7\u522B\uFF1A");
		
		JLabel lblNewLabel_4 = new JLabel("\u6D3B\u52A8\u5F00\u59CB\u65F6\u95F4\uFF1A");
		
		actlocationtxt = new JTextField();
		actlocationtxt.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("\u6D3B\u52A8\u62A5\u540D\u5730\u70B9\uFF1A");
		
		JLabel lblNewLabel_7 = new JLabel("\u6D3B\u52A8\u5956\u52B1\uFF1A");
		
		acttimetxt = new JTextField();
		acttimetxt.setColumns(10);
		
		actawardtxt = new JTextField();
		actawardtxt.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("\u6D3B\u52A8\u7F16\u53F7:");
		
		ActIDTxt = new JTextField();
		ActIDTxt.setColumns(10);
		
		ActtypeTxt = new JTextField();
		ActtypeTxt.setColumns(10);
		
		ActGradeTxt = new JTextField();
		ActGradeTxt.setColumns(10);
		
		
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(90)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE)
								.addComponent(lblNewLabel_7, GroupLayout.PREFERRED_SIZE, 68, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_4, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE)
								.addComponent(lblNewLabel_3, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE)
								.addComponent(lblNewLabel_6, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE)
								.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE)
								.addComponent(lblNewLabel_2))
							.addPreferredGap(ComponentPlacement.RELATED))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel_5, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
							.addGap(70)))
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
								.addComponent(actbaomingTxt, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
								.addComponent(acttimetxt, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
								.addComponent(actlocationtxt, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(btnNewButton)
									.addPreferredGap(ComponentPlacement.RELATED, 139, Short.MAX_VALUE)
									.addComponent(btnNewButton_1))
								.addComponent(actNameTxt, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
								.addGroup(groupLayout.createSequentialGroup()
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(actawardtxt, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)))
							.addGap(64))
						.addComponent(ActIDTxt, GroupLayout.PREFERRED_SIZE, 88, GroupLayout.PREFERRED_SIZE)
						.addComponent(ActtypeTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(ActGradeTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(21)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_5)
						.addComponent(ActIDTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(actNameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(33)
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblNewLabel_3)
								.addComponent(ActGradeTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
						.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
							.addComponent(lblNewLabel_2)
							.addComponent(ActtypeTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(15)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(actbaomingTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(actlocationtxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_6))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(acttimetxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_4))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(actawardtxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_7))
					.addPreferredGap(ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton_1)
						.addComponent(btnNewButton))
					.addGap(20))
		);
		getContentPane().setLayout(groupLayout);
		
		actbaomingTxt.setBorder(new LineBorder(new java.awt.Color(127,157,185), 1, false));
		fillAType();
	}
	private void ActivitiesAddActionPerformed(ActionEvent evt){
		String actName=actNameTxt.getText();
		String actbm=actbaomingTxt.getText();
		String actadd=actlocationtxt.getText();
		String actt=acttimetxt.getText();
		String actaw=actawardtxt.getText();
		String atype=ActtypeTxt.getText();
		String agrade=ActGradeTxt.getText();
		String aid=ActIDTxt.getText();
		
		if(StringUtil.isEmpty(aid)){
			JOptionPane.showMessageDialog(null, "�ID����Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(actName)){
			JOptionPane.showMessageDialog(null, "����Ʋ���Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(actbm)){
			JOptionPane.showMessageDialog(null, "������ʽ����Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(actadd)){
			JOptionPane.showMessageDialog(null, "�����ص㲻��Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(actt)){
			JOptionPane.showMessageDialog(null, "��ʼʱ�䲻��Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(actaw)){
			JOptionPane.showMessageDialog(null, "���������Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(atype)){
			JOptionPane.showMessageDialog(null, "����Ͳ���Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(agrade)){
			JOptionPane.showMessageDialog(null, "�������Ϊ�գ�");
			return;
		}
		activities activity=new activities(aid,actName,atype,agrade,actadd,actt,actbm,actaw);
		Connection con=null;
		try {
			con=dbUtil.getCon();
			int n=ActivitiesDao.add(con, activity);
			if(n==1){
				JOptionPane.showMessageDialog(null, "����ӳɹ���");
				resetValues();
			}else{
				JOptionPane.showMessageDialog(null, "�����ʧ�ܣ�");
			}
		} catch (Exception e2) {
			e2.printStackTrace(); 
			JOptionPane.showMessageDialog(null, "�����ʧ�ܣ�");
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * �����¼�����
	 * @param evt
	 */
	private void resetValueActionPerformed(ActionEvent evt){
		this.resetValues();
	}
	/*
	 * 		String actName=actNameTxt.getText();
		String actbm=actbaomingTxt.getText();
		String actadd=actlocationtxt.getText();
		String actt=acttimetxt.getText();
		String actaw=actawardtxt.getText();
		String atype=ActtypeTxt.getText();
		String agrade=ActGradeTxt.getText();*/
	private void resetValues(){
		this.actNameTxt.setText("");
		this.actbaomingTxt.setText("");
		this.actlocationtxt.setText("");
		this.acttimetxt.setText("");
		this.actawardtxt.setText("");
		this.ActtypeTxt.setText("");
		this.ActGradeTxt.setText("");
	}
}
