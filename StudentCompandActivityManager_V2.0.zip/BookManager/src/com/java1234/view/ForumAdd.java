package com.java1234.view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Date;
import java.text.SimpleDateFormat;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import com.java1234.model.Forum;
import com.java1234.dao.ForumDao;
import com.java1234.util.DbUtil;
import com.java1234.util.StringUtil;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;

public class ForumAdd extends JInternalFrame {
	
	private DbUtil dbUtil=new DbUtil();
	private ForumDao ForumDao=new ForumDao();
	private JTextField TietitleTxt;
	
	private JComboBox Comptypejcb;
	private JComboBox Compclassjcb;
	private JTextField TieContentTxt;
	private JRadioButton exprbt=null;
	private JRadioButton comprbt=null;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ForumAdd frame = new ForumAdd();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/*
	private void fillAType() {
		Connection con = null;
		ForumAdd ForumAdd = null;
		try {
			con = dbUtil.getCon();
			ResultSet rs = ForumDao.list(con, new Forum());
			while (rs.next()) {
				ForumAdd = new ForumAdd();
				//activities.set(rs.getInt("id"));
				ForumAdd.setTitle(rs.getString("CTYPE"));
				//this.Comptypejcb.addItem(Competition);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}*/
	/**
	 * Create the frame.
	 */
	public ForumAdd() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u5199\u5E16\u5B50");
		setBounds(100, 100, 587, 433);
		
		JLabel lblNewLabel = new JLabel("\u5E16\u5B50\u6807\u9898\uFF1A");
		
		TietitleTxt = new JTextField();
		TietitleTxt.setColumns(10);
		
		JButton btnNewButton = new JButton("\u6DFB\u52A0");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ActivitiesAddActionPerformed(e);
			}
		});
		btnNewButton.setIcon(new ImageIcon(ForumAdd.class.getResource("/images/add.png")));
		
		JButton btnNewButton_1 = new JButton("\u91CD\u7F6E");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetValueActionPerformed(e);
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(ForumAdd.class.getResource("/images/reset.png")));
		
		JLabel lblNewLabel_2 = new JLabel("\u5E16\u5B50\u5185\u5BB9\uFF1A");
		
		TieContentTxt = new JTextField();
		TieContentTxt.setColumns(10);
		
		exprbt = new JRadioButton("\u4EA4\u6D41\u7ECF\u9A8C");
		buttonGroup.add(exprbt);
		
		comprbt = new JRadioButton("\u6BD4\u8D5B\u7EC4\u961F");
		buttonGroup.add(comprbt);
		
		JLabel lblNewLabel_1 = new JLabel("\u5E16\u5B50\u7C7B\u578B\uFF1A");
		
		
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(90)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_2, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE)
						.addComponent(lblNewLabel)
						.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(exprbt, GroupLayout.PREFERRED_SIZE, 127, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
							.addComponent(comprbt, GroupLayout.PREFERRED_SIZE, 127, GroupLayout.PREFERRED_SIZE))
						.addComponent(TieContentTxt, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(btnNewButton)
							.addPreferredGap(ComponentPlacement.RELATED, 139, Short.MAX_VALUE)
							.addComponent(btnNewButton_1))
						.addComponent(TietitleTxt, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE))
					.addGap(64))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(13)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
							.addComponent(exprbt)
							.addComponent(comprbt))
						.addComponent(lblNewLabel_1))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(TietitleTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(TieContentTxt, GroupLayout.PREFERRED_SIZE, 206, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton_1)
						.addComponent(btnNewButton))
					.addGap(20))
		);
		getContentPane().setLayout(groupLayout);
		//fillAType();
	}
	
	/**
	 * ͼ����������¼�����
	 * @param evt
	 */
	private void ActivitiesAddActionPerformed(ActionEvent evt){
		String CName=TietitleTxt.getText();
		String Ctype=TieContentTxt.getText();
		String type="";
		if(exprbt.isSelected()){
			type="���齻��";
		}else if(comprbt.isSelected()){
			type="�������";
		}
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
        String id=df.format(new Date());// new Date()Ϊ��ȡ��ǰϵͳʱ��
		if(StringUtil.isEmpty(CName)){
			JOptionPane.showMessageDialog(null, "���ӱ��ⲻ��Ϊ�գ�");
			return;
		}

		if(StringUtil.isEmpty(Ctype)){
			JOptionPane.showMessageDialog(null, "�������ݲ���Ϊ�գ�");
			return;}
		Forum Forum=new Forum(id,CName,type,Ctype);
		Connection con=null;
		try {
			con=dbUtil.getCon();
			int n=ForumDao.add(con, Forum);
			if(n==1){
				JOptionPane.showMessageDialog(null, "���ӷ����ɹ���");
				resetValues();
			}else{
				JOptionPane.showMessageDialog(null, "���ӷ���ʧ�ܣ�");
			}
		} catch (Exception e2) {
			e2.printStackTrace(); 
			JOptionPane.showMessageDialog(null, "���ӷ���ʧ�ܣ�");
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	/**
	 * �����¼�����
	 * @param evt
	 */
	private void resetValueActionPerformed(ActionEvent evt){
		this.resetValues();
	}
	
	private void resetValues(){
		this.TietitleTxt.setText("");
		this.TieContentTxt.setText("");
	}
}
