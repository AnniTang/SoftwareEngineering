package com.java1234.view;

import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import com.java1234.dao.ForumDao;
import com.java1234.dao.BookTypeDao;
import com.java1234.dao.TeacherDao;
import com.java1234.model.Teacher;
import com.java1234.model.BookType;
import com.java1234.util.DbUtil;
import com.java1234.util.StringUtil;

public class TeacherManageInterFrm extends JInternalFrame {
	private JComboBox ReserchmodifyJcb=null;
	private JTextField TeacherNameTxt;
	private JRadioButton manJrb =null;
	private JRadioButton femaleJrb =null;
	private JTextArea TeacherappraiseTxt;
	
	private DbUtil dbUtil = new DbUtil();
	private TeacherDao TeacherDao = new TeacherDao();
	private JTextField idTxt;
	private JTextField TeacherNameTxt_1;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTextField TeacherteleTxt;
	private JTextField TeacherappTxt;
	private JTable TeacherTable;
	private JTextField TeachersexTxt;
	private JTextField TeacherResearchTxt;
	private JTextField TeacherResearchtxt;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TeacherManageInterFrm frame = new TeacherManageInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TeacherManageInterFrm() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u6559\u5E08\u4FE1\u606F\u7BA1\u7406");
		setBounds(100, 100, 917, 795);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "\u641C\u7D22\u6761\u4EF6", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "\u8868\u5355\u64CD\u4F5C", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
					.addGap(46)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(scrollPane, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 849, Short.MAX_VALUE)
						.addComponent(panel_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(panel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 849, Short.MAX_VALUE))
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(29)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 83, GroupLayout.PREFERRED_SIZE)
					.addGap(17)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 318, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 284, GroupLayout.PREFERRED_SIZE)
					.addGap(29))
		);
		
		TeacherTable = new JTable();
		TeacherTable.setFillsViewportHeight(true);
		TeacherTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				bookTableMousePressed(e);
			}
		});
		TeacherTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u6559\u5E08\u7F16\u53F7", "\u6559\u5E08\u59D3\u540D", "\u6559\u5E08\u7535\u8BDD", "\u7814\u7A76\u65B9\u5411", "\u6559\u5E08\u6210\u5C31", "\u6559\u5E08\u8BC4\u4EF7", "\u6559\u5E08\u6027\u522B"
			}
		));
		TeacherTable.getColumnModel().getColumn(0).setPreferredWidth(59);
		scrollPane.setColumnHeaderView(TeacherTable);
		
		JLabel lblNewLabel = new JLabel("\u7F16\u53F7\uFF1A");
		
		idTxt = new JTextField();
		idTxt.setEditable(false);
		idTxt.setColumns(10);
		
		JLabel label_3 = new JLabel("\u6559\u5E08\u59D3\u540D\uFF1A");
		
		TeacherNameTxt_1 = new JTextField();
		TeacherNameTxt_1.setColumns(10);
		
		JLabel label_4 = new JLabel("\u6027\u522B\uFF1A");
		
		manJrb = new JRadioButton("\u7537");
		manJrb.setSelected(true);
		buttonGroup.add(manJrb);
		
		femaleJrb = new JRadioButton("\u5973");
		buttonGroup.add(femaleJrb);
		
		JLabel label_5 = new JLabel("\u8054\u7CFB\u65B9\u5F0F\uFF1A");
		
		TeacherteleTxt = new JTextField();
		TeacherteleTxt.setColumns(10);
		
		JLabel label_6 = new JLabel("\u6210\u5C31\uFF1A");
		
		TeacherappTxt = new JTextField();
		TeacherappTxt.setColumns(10);
		
		JLabel label_7 = new JLabel("\u7814\u7A76\u65B9\u5411\uFF1A");
		
		JLabel lblNewLabel_1 = new JLabel("\u6559\u5E08\u7B80\u4ECB\uFF1A");
		
		
		TeacherappraiseTxt = new JTextArea();
		
		JButton btnNewButton = new JButton("\u4FEE\u6539");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookUpdateActionPerformed(e);
			}
		});
		btnNewButton.setIcon(new ImageIcon(TeacherManageInterFrm.class.getResource("/images/modify.png")));
		
		JButton btnNewButton_1 = new JButton("\u5220\u9664");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookDeleteActionPerformed(e);
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(TeacherManageInterFrm.class.getResource("/images/delete.png")));
		
		TeacherResearchtxt = new JTextField();
		TeacherResearchtxt.setColumns(10);
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(29)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING, false)
						.addGroup(Alignment.LEADING, gl_panel_1.createSequentialGroup()
							.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
								.addComponent(label_5)
								.addComponent(lblNewLabel))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
								.addComponent(idTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(TeacherteleTxt, GroupLayout.PREFERRED_SIZE, 94, GroupLayout.PREFERRED_SIZE))
							.addGap(10)
							.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING, false)
								.addGroup(gl_panel_1.createSequentialGroup()
									.addComponent(label_3)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(TeacherNameTxt_1, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_panel_1.createSequentialGroup()
									.addComponent(label_6)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(TeacherappTxt)))
							.addGap(32)
							.addGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING)
								.addComponent(label_4)
								.addComponent(label_7))
							.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel_1.createSequentialGroup()
									.addGap(18)
									.addComponent(manJrb)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(femaleJrb))
								.addGroup(gl_panel_1.createSequentialGroup()
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(TeacherResearchtxt, GroupLayout.PREFERRED_SIZE, 102, GroupLayout.PREFERRED_SIZE))))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addComponent(lblNewLabel_1)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING, false)
								.addGroup(gl_panel_1.createSequentialGroup()
									.addComponent(btnNewButton)
									.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(btnNewButton_1))
								.addComponent(TeacherappraiseTxt, GroupLayout.PREFERRED_SIZE, 483, GroupLayout.PREFERRED_SIZE))))
					.addGap(107))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(25)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(label_3)
						.addComponent(TeacherNameTxt_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_4)
						.addComponent(manJrb)
						.addComponent(femaleJrb)
						.addComponent(idTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(30)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_5)
						.addComponent(TeacherteleTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_6)
						.addComponent(TeacherappTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_7)
						.addComponent(TeacherResearchtxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(31)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(TeacherappraiseTxt, GroupLayout.PREFERRED_SIZE, 63, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_1))
					.addGap(18)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addComponent(btnNewButton_1)
						.addComponent(btnNewButton))
					.addContainerGap(23, Short.MAX_VALUE))
		);
		panel_1.setLayout(gl_panel_1);
		
		JLabel label = new JLabel("\u6559\u5E08\u59D3\u540D\uFF1A");
		
		TeacherNameTxt = new JTextField();
		TeacherNameTxt.setColumns(10);
		
		JLabel label_1 = new JLabel("\u6559\u5E08\u6027\u522B\uFF1A");
		
		JLabel label_2 = new JLabel("\u7814\u7A76\u65B9\u5411\uFF1A");
		
		JButton button = new JButton("\u67E5\u8BE2");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookSearchActionPerformed(e);
			}

			
		});
		button.setIcon(new ImageIcon(TeacherManageInterFrm.class.getResource("/images/search.png")));
		
		TeachersexTxt = new JTextField();
		TeachersexTxt.setColumns(10);
		
		TeacherResearchTxt = new JTextField();
		TeacherResearchTxt.setColumns(10);
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(19)
					.addComponent(label)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(TeacherNameTxt, GroupLayout.PREFERRED_SIZE, 112, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(label_1)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(TeachersexTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(52)
					.addComponent(label_2)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(TeacherResearchTxt, GroupLayout.PREFERRED_SIZE, 206, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
					.addComponent(button)
					.addGap(37))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(TeacherNameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_1)
						.addComponent(label_2)
						.addComponent(TeachersexTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(TeacherResearchTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(button))
					.addContainerGap(25, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		getContentPane().setLayout(groupLayout);

		TeacherappraiseTxt.setBorder(new LineBorder(new java.awt.Color(127,157,185), 1, false));
		
		//this.fillBookType("search");
		//this.fillBookType("modify");
		this.fillTable(new Teacher());
	}
	
	/**
	 * ɾ���¼�����
	 * @param e
	 */
	private void bookDeleteActionPerformed(ActionEvent evt) {
		String id = this.idTxt.getText();
		if (StringUtil.isEmpty(id)) {
			JOptionPane.showMessageDialog(null, "��ѡ��Ҫɾ���ļ�¼��");
			return;
		}
		int n = JOptionPane.showConfirmDialog(null, "ȷ��Ҫɾ��������¼��");
		if (n == 0) {
			Connection con = null;
			try {
				con = dbUtil.getCon();
				int deleteNum = TeacherDao.delete(con, id);
				if (deleteNum == 1) {
					JOptionPane.showMessageDialog(null, "ɾ���ɹ�");
					this.resetValue();
					this.fillTable(new Teacher());
				} else {
					JOptionPane.showMessageDialog(null, "ɾ��ʧ��");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "ɾ��ʧ��");
			} finally {
				try {
					dbUtil.closeCon(con);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * �޸��¼�����
	 * @param e
	 */
	private void bookUpdateActionPerformed(ActionEvent evt) {
		String id = this.idTxt.getText();
		if (StringUtil.isEmpty(id)) {
			JOptionPane.showMessageDialog(null, "��ѡ��Ҫ�޸ĵļ�¼��");
			return;
		}
		
		String teacherName=this.TeacherNameTxt_1.getText();
		String teacherapp=this.TeacherappTxt.getText();
		String teacheradd=this.TeacherteleTxt.getText();
		String teacherappr=this.TeacherappraiseTxt.getText();
		String teacheresearch=this.TeacherResearchtxt.getText();
		//String tno=this.TeacherResearchtxt.getText();
		if(StringUtil.isEmpty(teacherName)){
			JOptionPane.showMessageDialog(null, "��ʦ��������Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(teacherapp)){
			JOptionPane.showMessageDialog(null, "��ʦ�ɾͲ���Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(teacheradd)){
			JOptionPane.showMessageDialog(null, "��ʦ��ϵ��ʽ����Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(teacherappr)){
			JOptionPane.showMessageDialog(null, "��ʦ���۲���Ϊ�գ�");
			return;
		}
		if(StringUtil.isEmpty(teacheresearch)){
			JOptionPane.showMessageDialog(null, "��ʦ�о�������Ϊ�գ�");
			return;
		}
		
		String sex="";
		if(this.manJrb.isSelected()){
			sex="��";
		}else if(this.femaleJrb.isSelected()){
			sex="Ů";
		}
		
		//Teacher teacheresearch=(Teacher) this.ReserchmodifyJcb.getSelectedItem();

		//	public Teacher(String TNO,String TNAME, String TCONTACT, String TRESEARCH,String  TACCOMPLISHMENT,String TAPPRAISE,String TSEX) 
		Teacher teacher=new Teacher(id,teacherName,teacheradd,teacheresearch,teacherapp,teacherappr,sex);
		Connection con = null;
		try {
			con = dbUtil.getCon();
			int modifyNum = TeacherDao.update(con, teacher);
			if (modifyNum == 1) {
				JOptionPane.showMessageDialog(null, "�޸ĳɹ�");
				this.resetValue();
				this.fillTable(new Teacher());
			} else {
				JOptionPane.showMessageDialog(null, "�޸�ʧ��");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "�޸�ʧ��");
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	/**
	 * �����е���¼�����
	 * @param evt
	 */
	private void bookTableMousePressed(MouseEvent evt) {
		// ��ȡѡ�е���
		int row = this.TeacherTable.getSelectedRow();
		this.idTxt.setText((String) TeacherTable.getValueAt(row, 0));
		this.TeacherNameTxt_1.setText((String) TeacherTable.getValueAt(row, 1));
		this.TeacherappTxt.setText((String) TeacherTable.getValueAt(row, 4));
		this.TeacherteleTxt.setText((String) TeacherTable.getValueAt(row, 2));
		this.TeacherappraiseTxt.setText((String) TeacherTable.getValueAt(row, 5));
		String sex = (String) TeacherTable.getValueAt(row, 6);
		if ("��".equals(sex)) {
			this.manJrb.setSelected(true);
		} else if ("Ů".equals(sex)) {
			this.femaleJrb.setSelected(true);
		}
		this.TeacherResearchtxt.setText((String) TeacherTable.getValueAt(row, 3));

		/*
		int n = this.bookTypeJcb.getItemCount();
		for (int i = 0; i < n; i++) {
			Student item = (Student) this.bookTypeJcb.getItemAt(i);
			if (item.getBookTypeName().equals(bookTypeName)) {
				this.bookTypeJcb.setSelectedIndex(i);
				
			}
		}
		*/
	}
	/**
	 * ��ʼ��������
	 * @param type ����������
	 */
	/*
	private void fillBookType(String type) {
		Connection con = null;
		Teacher Teacher = null;
		try {
			con = dbUtil.getCon();
			ResultSet rs = TeacherDao.list(con, new Teacher());
			if ("search".equals(type)) {
				Teacher = new Teacher();
				Teacher.setTNAME("��ѡ��...");
				Teacher.setTNO(-1);
				this.teachersexJcb.addItem(Teacher);
			}
			while (rs.next()) {
				Teacher = new Teacher();
				Teacher.setTNO(rs.getInt("TNO"));
				Teacher.setTNAME(rs.getString("TNAME"));
				if ("search".equals(type)) {
					this.teachersexJcb.addItem(Teacher);
				} else if ("modify".equals(type)) {
					this.teachersexJcb.addItem(Teacher);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	*/
	/**
	 * ��ʼ����������
	 * @param book
	 */
	private void fillTable(Teacher Teacher) {
		DefaultTableModel dtm = (DefaultTableModel) TeacherTable.getModel();
		dtm.setRowCount(0);
		Connection con = null;
		try {
			con = dbUtil.getCon();
			ResultSet rs = TeacherDao.list(con, Teacher);
			while (rs.next()) {
				Vector v = new Vector();
				v.add(rs.getString("TNO"));
				v.add(rs.getString("TNAME"));
				v.add(rs.getString("TCONTACT"));
				v.add(rs.getString("TRESEARCH"));
				v.add(rs.getString("TACCOMPLISHMENT"));
				v.add(rs.getString("TAPPRAISE"));
				v.add(rs.getString("TSEX"));
				dtm.addRow(v);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * ͼ���ѯ�¼���������
	 * @param evt
	 */
	private void bookSearchActionPerformed(ActionEvent evt) {
		String TName = this.TeacherNameTxt.getText();
		String TSEX = this.TeachersexTxt.getText();
		String TRESERACH = this.TeacherResearchTxt.getText();
		//String TId = Teacher.getTNO();

		Teacher Teacher = new Teacher(TName, TSEX, TRESERACH);

		this.fillTable(Teacher);
		this.resetValue();
	}
	/**
	 * ���ñ���
	 */
	private void resetValue() {
		this.idTxt.setText("");
		this.TeacherNameTxt_1.setText("");
		this.TeacherappTxt.setText("");
		this.manJrb.setSelected(true);
		this.TeacherteleTxt.setText("");
		this.TeacherappraiseTxt.setText("");
		this.TeacherResearchtxt.setText("");
		/*
		if (this.ReserchmodifyJcb.getItemCount() > 0) {
			this.ReserchmodifyJcb.setSelectedIndex(0);
			
		}*/
	}
}
